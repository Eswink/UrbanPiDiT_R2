"""Shared model/checkpoint utilities for bounded, local R7 experiments."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import random
import tempfile
import numpy as np
import torch


def make_model(kind,config):
    from model.weather_forecaster_r7 import NativeAtmosForecaster
    from model.recursive_weather_r7 import GenericRecursiveWeatherForecaster
    from model.process_forecast_r7 import ProcessForecastCoReasoner
    from model.r7_baselines import UNetForecaster,ConvLSTMForecaster,AFNOSmallForecaster
    options=dict(config)
    architecture=options.pop('architecture','window')
    if kind=='native':
        native={'window':NativeAtmosForecaster,'unet':UNetForecaster,'convlstm':ConvLSTMForecaster,'afno_small':AFNOSmallForecaster}
        if architecture not in native:
            raise ValueError(f'unsupported native architecture: {architecture}')
        return native[architecture](**options)
    recursive={'generic':GenericRecursiveWeatherForecaster,'process':ProcessForecastCoReasoner}
    if kind not in recursive or architecture!='window':
        raise ValueError(f'unsupported model kind/architecture: {kind}/{architecture}')
    return recursive[kind](**options)


def model_code_digest():
    import model
    directory=Path(model.__file__).resolve().parent
    digest=hashlib.sha256()
    for path in sorted(directory.rglob('*.py')):
        if 'legacy' in str(path.relative_to(directory)):
            continue
        digest.update(path.relative_to(directory).as_posix().encode()+b'\0')
        digest.update(path.read_bytes())
    return digest.hexdigest()


def select_device(name,bf16=False):
    device=torch.device(name)
    if device.type not in ('cpu','cuda'):
        raise ValueError('single CPU/CUDA devices only')
    if device.type=='cuda':
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA requested but unavailable; no CPU fallback')
        # set_device requires an integer index; a bare torch.device('cuda') has
        # index None and is rejected by torch>=2.8. Fall back to the current
        # device so plain 'cuda' keeps meaning "the default visible device"
        # (and remains correct under CUDA_VISIBLE_DEVICES).
        torch.cuda.set_device(device.index if device.index is not None else torch.cuda.current_device())
        if bf16 and not torch.cuda.is_bf16_supported():
            raise RuntimeError('BF16 requested but unsupported')
    return device


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def rng_state():
    n=np.random.get_state()
    return {'python':random.getstate(),'numpy':[n[0],n[1].tolist(),int(n[2]),int(n[3]),float(n[4])],
        'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state['python'])
    n=state['numpy']
    np.random.set_state((n[0],np.asarray(n[1],dtype=np.uint32),n[2],n[3],n[4]))
    torch.set_rng_state(state['torch'].cpu())
    if state['cuda']:
        if not torch.cuda.is_available() or len(state['cuda'])!=torch.cuda.device_count():
            raise ValueError('checkpoint CUDA RNG topology differs')
        torch.cuda.set_rng_state_all([x.cpu() for x in state['cuda']])


def canonical_digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def dataset_identity(manifest):
    """Bind bounded metadata/norms, not every raw chunk; source audit is separate."""
    from data.r7_zarr_dataset import ZarrAtmosWindowDataset
    ds=ZarrAtmosWindowDataset(manifest)
    roots={}
    for rec in ds.records:
        key=rec['store_path']
        if key in roots:
            continue
        root=ds._store(rec)
        arrays=['latitude','longitude','time_ns','normalization_mean','normalization_std']
        arrays += [n for n in ['process_normalization_mean','process_normalization_std'] if n in root]
        roots[key]={'attributes':dict(root.attrs),'shape':list(root['state'].shape),
            'arrays':{n:hashlib.sha256(np.asarray(root[n][:]).tobytes()).hexdigest() for n in arrays}}
    return canonical_digest({'manifest_sha256':hashlib.sha256(Path(manifest).read_bytes()).hexdigest(),'stores':roots}),ds


def save_exclusive(path,payload):
    path=Path(path)
    if path.exists() or path.is_symlink():
        raise FileExistsError(path)
    if payload.get('format')=='r7-local-v1':
        payload=dict(payload,model_code_sha256=model_code_digest())
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix='.r7-checkpoint-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            torch.save(payload,f)
            f.flush()
            os.fsync(f.fileno())
        os.link(temp,path)
    finally:
        os.unlink(temp)


def load_checkpoint(path,*,expected=None):
    checkpoint=torch.load(path,map_location='cpu',weights_only=True)
    if checkpoint.get('format')!='r7-local-v1':
        raise ValueError('unsupported R7 checkpoint format')
    if checkpoint.get('model_code_sha256')!=model_code_digest():
        raise ValueError('checkpoint model implementation differs; use the recorded code revision for exact evaluation/resume')
    if expected is not None and checkpoint['signature']!=expected:
        raise ValueError('checkpoint model/data/training identity differs')
    if checkpoint['signature']!=canonical_digest(checkpoint['contract']):
        raise ValueError('checkpoint contract digest mismatch')
    return checkpoint
